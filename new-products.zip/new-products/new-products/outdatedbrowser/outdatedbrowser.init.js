// Initialization of Outdated Browser Plugin

$( document ).ready(function() {
  outdatedBrowser({
      bgColor: '#db6e79',
      color: '#ffffff',
      lowerThan: 'boxShadow',
      languagePath: ''
  });
});   
